// generated from rosidl_generator_c/resource/idl.h.em
// with input from lifecycle_msgs:msg/State.idl
// generated code does not contain a copyright notice

#ifndef LIFECYCLE_MSGS__MSG__STATE_H_
#define LIFECYCLE_MSGS__MSG__STATE_H_

#include "lifecycle_msgs/msg/detail/state__struct.h"
#include "lifecycle_msgs/msg/detail/state__functions.h"
#include "lifecycle_msgs/msg/detail/state__type_support.h"

#endif  // LIFECYCLE_MSGS__MSG__STATE_H_
